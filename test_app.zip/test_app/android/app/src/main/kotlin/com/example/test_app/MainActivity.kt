package com.example.test_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
